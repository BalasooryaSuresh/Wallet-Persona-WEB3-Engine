# main.py
import os, re, time, httpx
from datetime import datetime
from collections import defaultdict

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from web3 import Web3, HTTPProvider

# ---------- CONFIG ----------
ETH_RPC = os.getenv("ETH_RPC") or "https://worldchain-mainnet.g.alchemy.com/v2/QmErVMyRN-deHWdCKDpT8dlW4jFh0H5C"
ETHERSCAN_API = os.getenv("ETHERSCAN_API")  # optional but recommended
ADDR_RE = re.compile(r"^0x[a-fA-F0-9]{40}$")
web3 = Web3(HTTPProvider(ETH_RPC, request_kwargs={"timeout": 15}))
if not web3.is_connected():
    raise RuntimeError("Cannot connect to RPC node")
# ----------------------------

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/frontend", StaticFiles(directory="frontend"), name="frontend")


# ------------- HELPERS -------------
def calc_risk(balance_eth: float, tx_cnt: int) -> int:
    score = 100
    if balance_eth < 0.05:
        score -= 30
    elif balance_eth < 0.2:
        score -= 15
    if tx_cnt < 5:
        score -= 35
    elif tx_cnt < 25:
        score -= 15
    return max(score, 0)


def simple_bio(balance_eth: float, tx_cnt: int, age_days: int) -> str:
    seniority = (
        "veteran" if age_days > 730 else "mid-tier" if age_days > 180 else "newcomer"
    )
    activity = (
        "power user"
        if tx_cnt > 200
        else "steady participant"
        if tx_cnt > 50
        else "occasional explorer"
    )
    wealth = (
        "whale 🐳"
        if balance_eth > 50
        else "solid stack holder"
        if balance_eth > 5
        else "lean adventurer"
    )
    return f"{seniority} {activity} • {wealth} • active for {age_days} days"


async def fetch_txs(address: str) -> list[dict]:
    """Return tx list (may be empty if ETHERSCAN_API missing)."""
    if not ETHERSCAN_API:
        return []
    url = (
        "https://api.etherscan.io/api"
        f"?module=account&action=txlist&address={address}"
        "&startblock=0&endblock=99999999&sort=asc"
        f"&apikey={ETHERSCAN_API}"
    )
    async with httpx.AsyncClient(timeout=20) as client:
        res = await client.get(url)
    data = res.json()
    return data.get("result", []) if data.get("status") == "1" else []


def build_timeline(txs: list[dict]):
    """Return dict: {YYYY-MM: count} for chart.js."""
    months = defaultdict(int)
    first_ts = None
    for tx in txs:
        ts = int(tx["timeStamp"])
        if first_ts is None:
            first_ts = ts
        dt = datetime.utcfromtimestamp(ts)
        key = f"{dt.year}-{dt.month:02d}"
        months[key] += 1
    # sort months chronologically
    labels = sorted(months.keys())
    counts = [months[m] for m in labels]
    return {
        "labels": labels,
        "counts": counts,
        "age_days": int((time.time() - first_ts) / 86400) if first_ts else 0,
    }


def recommend(balance_eth: float, tx_cnt: int) -> dict:
    """Very simple heuristics."""
    dapps = ["Uniswap", "Aave", "Lens Protocol"]
    nfts = ["Pudgy Penguins", "Azuki", "Milady"]
    if balance_eth < 0.05:
        dapps.insert(0, "Faucet (Goerli / Sepolia)")
    if tx_cnt > 50:
        dapps.append("1inch")
    return {"dapps": dapps[:4], "nfts": nfts[:4]}


# ------------- API -------------
class WalletReq(BaseModel):
    address: str


@app.get("/", response_class=HTMLResponse)
async def root():
    with open("frontend/index.html", "r", encoding="utf-8") as f:
        return f.read()


@app.post("/persona")
async def persona(req: WalletReq):
    raw = req.address.strip()
    if not ADDR_RE.fullmatch(raw):
        raise HTTPException(400, "Invalid address")

    address = Web3.to_checksum_address(raw)
    balance_wei = web3.eth.get_balance(address)
    tx_cnt = web3.eth.get_transaction_count(address)
    balance_eth = balance_wei / 1e18
    risk = calc_risk(balance_eth, tx_cnt)

    # fetch txs (async)
    txs = await fetch_txs(address)
    timeline = build_timeline(txs)

    bio = simple_bio(balance_eth, tx_cnt, timeline["age_days"])
    rec = recommend(balance_eth, tx_cnt)

    return {
        "address": address,
        "balance": round(balance_eth, 4),
        "txCount": tx_cnt,
        "riskScore": risk,
        "bio": bio,
        "recommendations": rec,
        "timeline": timeline,
    }


# -------- dev auto-launch (optional) -------
if __name__ == "__main__":
    import threading, webbrowser, uvicorn, time as _t

    def open_browser():
        _t.sleep(1)
        webbrowser.open("http://127.0.0.1:8000")

    threading.Thread(target=open_browser, daemon=True).start()
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=False)
