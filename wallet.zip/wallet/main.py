import os, re, threading, webbrowser, random
from datetime import datetime, timedelta

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from web3 import Web3, HTTPProvider
import numpy as np
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import cosine_similarity

# ---------- CONFIG ----------
ETH_RPC = os.getenv("ETH_RPC") or "https://eth-mainnet.g.alchemy.com/v2/QmErVMyRN-deHWdCKDpT8dlW4jFh0H5C"
ADDR_RE = re.compile(r"^0x[a-fA-F0-9]{40}$")
web3      = Web3(HTTPProvider(ETH_RPC, request_kwargs={"timeout": 15}))
if not web3.is_connected():
    raise RuntimeError("Ethereum RPC not reachable")
# ----------------------------

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
)
app.mount("/frontend", StaticFiles(directory="frontend"), name="frontend")

# ---------- DATA ----------
wallet_db: dict[str, dict] = {}          # address -> feature dict
kmeans: KMeans | None = None             # global clustering model

# ---------- HELPERS ----------
def heuristic_bio(balance, tx):
    if balance > 10 and tx > 100:
        return "High-volume whale active across DeFi & NFTs."
    if tx > 100:
        return "DeFi power-user with frequent trades."
    if balance > 5:
        return "Long-term holder with solid stack."
    if tx < 5:
        return "New or dormant wallet."
    return "Casual user exploring the ecosystem."

def recommend(cluster: int | None):
    if cluster == 0:  # light users
        return ["OpenSea", "Lens Protocol", "Rainbow"]
    if cluster == 1:  # medium
        return ["Uniswap", "Zapper", "Mirror"]
    if cluster == 2:  # heavy
        return ["Aave", "Blur", "dYdX"]
    return ["Uniswap", "OpenSea"]

def estimate_first_seen(tx_count):
    if tx_count == 0:
        return "Unknown"
    days_ago = random.randint(30, 720)
    return (datetime.utcnow() - timedelta(days=days_ago)).strftime("%Y-%m-%d")

def update_clusters():
    global kmeans
    if len(wallet_db) < 3:
        return
    X = np.array([[w["balance"], w["tx"]] for w in wallet_db.values()])
    kmeans = KMeans(n_clusters=3, n_init=10, random_state=42)
    labels = kmeans.fit_predict(X)
    for addr, lbl in zip(wallet_db, labels):
        wallet_db[addr]["cluster"] = int(lbl)

def most_similar(addr: str, top_k=3):
    if addr not in wallet_db or len(wallet_db) < 2:
        return []
    base = np.array([[wallet_db[addr]["balance"], wallet_db[addr]["tx"]]])
    others = [(a, np.array([d["balance"], d["tx"]]))
              for a, d in wallet_db.items() if a != addr]
    vecs = np.array([v for _, v in others])
    sims = cosine_similarity(base, vecs)[0]
    ranked = sorted(zip(others, sims), key=lambda x: -x[1])[:top_k]
    return [{"address": a, "score": float(f"{s:.3f}")} for (a, _), s in ranked]

# ---------- MODELS ----------
class WalletReq(BaseModel):
    address: str
class SimReq(BaseModel):
    address1: str
    address2: str

# ---------- ROUTES ----------
@app.get("/")
async def root():
    with open("frontend/index.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read(), status_code=200)


@app.post("/persona")
async def persona(req: WalletReq):
    raw = req.address.strip()
    if not ADDR_RE.fullmatch(raw):
        raise HTTPException(400, "Invalid address")

    try:
        address = Web3.to_checksum_address(raw)
        bal_wei  = web3.eth.get_balance(address)
        tx_cnt   = web3.eth.get_transaction_count(address)
        bal_eth  = bal_wei / 1e18

        # mock extra metrics
        first_seen = estimate_first_seen(tx_cnt)
        gas_used   = tx_cnt * random.randint(40_000, 80_000)

        # store/update DB
        wallet_db[address] = {"balance": bal_eth, "tx": tx_cnt}
        update_clusters()
        cluster = wallet_db[address].get("cluster")

        data = {
            "address": address,
            "balance": f"{bal_eth:.4f}",
            "txCount": tx_cnt,
            "firstSeen": first_seen,
            "gasUsed": gas_used,
            "cluster": cluster,
            "persona": heuristic_bio(bal_eth, tx_cnt),
            "recommendations": recommend(cluster)
        }
        return data
    except Exception as e:
        raise HTTPException(502, f"RPC error: {e}")

@app.post("/similarity")
async def similarity(req: SimReq):
    for a in (req.address1, req.address2):
        if not ADDR_RE.fullmatch(a.strip()):
            raise HTTPException(400, "Invalid address")
    # Ensure both wallets processed
    for addr in (req.address1, req.address2):
        if addr not in wallet_db:
            await persona(WalletReq(address=addr))
    vec1 = np.array([wallet_db[req.address1]["balance"], wallet_db[req.address1]["tx"]])
    vec2 = np.array([wallet_db[req.address2]["balance"], wallet_db[req.address2]["tx"]])
    sim  = float(cosine_similarity([vec1], [vec2])[0][0])
    return {"similarity": sim}

# ---------- AUTO-LAUNCH ----------
def open_browser():
    webbrowser.open_new("http://127.0.0.1:8000")
if __name__ == "__main__":
    threading.Timer(1.2, open_browser).start()
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000, reload=False)
